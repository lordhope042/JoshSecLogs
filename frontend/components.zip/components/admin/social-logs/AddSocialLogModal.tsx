"use client";

import { useMemo, useState } from "react";
import { X, ChevronLeft } from "lucide-react";
import { toast } from "sonner";

import { createSocialLog } from "@/services/socialLogs";
import type {
  CreateSocialLogDto,
  SocialLogPageType,
  SocialPlatform,
  InstagramSubType,
  VpnType,
  TutorialType,
  WebsiteType,
  WorkingToolType,
} from "@/types/social-log";
import { WIZARD_GROUPS, getGroup, type WizardGroup } from "@/shared/category-tree";

type WizardStep = 1 | 2 | 3 | 4;

const STEP_LABELS = ["Platform", "Category", "Audience", "Details"];

const TWITTER_FOLLOWER_TIERS: { value: number; label: string }[] = [
  { value: 0, label: "Empty Aged" },
  { value: 100, label: "100+" },
  { value: 200, label: "200+" },
  { value: 500, label: "500+" },
];

const TIKTOK_FOLLOWER_TIERS: { value: number; label: string }[] = [
  { value: 200, label: "200+" },
  { value: 500, label: "500+" },
  { value: 1000, label: "1K+" },
];

interface WizardState {
  group?: WizardGroup;
  selectedPageTypes: SocialLogPageType[];
  selectedPlatforms: SocialPlatform[];
  selectedSubTypes: string[];
  selectedCountries: string[];
  includeFollowerTier: boolean;
  country?: string;
  followers?: number;
  age?: number;
  details: Record<string, any>;
}

const initialWizardState: WizardState = {
  selectedPageTypes: [],
  selectedPlatforms: [],
  selectedSubTypes: [],
  selectedCountries: [],
  includeFollowerTier: false,
  details: {},
};

interface Submission {
  platform: SocialPlatform;
  category: string;
  pageType?: SocialLogPageType;
  country?: string;
  followers?: number;
  instagramSubType?: InstagramSubType;
  vpnType?: VpnType;
  tutorialType?: TutorialType;
  websiteType?: WebsiteType;
  workingToolType?: WorkingToolType;
  label: string;
}

interface AddSocialLogModalProps {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}

export default function AddSocialLogModal({ open, onClose, onCreated }: AddSocialLogModalProps) {
  const [step, setStep] = useState<WizardStep>(1);
  const [wizard, setWizard] = useState<WizardState>(initialWizardState);
  const [submitting, setSubmitting] = useState(false);

  const group = wizard.group ? getGroup(wizard.group) : undefined;
  const isWorkingTool = group?.value === "WORKING_TOOLS";
  const needsPlatformChoice =
    (group?.platforms.length ?? 0) > 1 &&
    group?.value !== "FACEBOOK" &&
    group?.value !== "TUTORIAL" &&
    group?.value !== "WEBSITE";

  const submissions: Submission[] = useMemo(() => {
    if (!group) return [];

    if (group.value === "FACEBOOK") {
      const subs: Submission[] = wizard.selectedPageTypes.map((pt) => ({
        platform: "FACEBOOK",
        category: "FACEBOOK_PAGE",
        pageType: pt,
        followers: pt === "PAGE_WITH_FOLLOWERS" ? (wizard.followers ?? 1000) : undefined,
        label: group.pageTypes?.find((p) => p.value === pt)?.label ?? pt,
      }));
      return subs;
    }

    if (group.value === "TIKTOK") {
      const subs: Submission[] = [];
      if (wizard.includeFollowerTier) {
        subs.push({
          platform: "TIKTOK",
          category: "TIKTOK_FOLLOWERS",
          followers: wizard.followers ?? 200,
          label: "Follower Tier",
        });
      }
      for (const c of wizard.selectedCountries) {
        const cfg = group.countries?.find((x) => x.value === c);
        subs.push({
          platform: "TIKTOK",
          category: "TIKTOK_COUNTRY",
          country: c,
          label: `${cfg?.label ?? c} Aged TikTok`,
        });
      }
      return subs;
    }

    if (group.value === "ICLOUD") {
      // Fixed product — always USA. If more countries are ever added to
      // the group's country list, the first selected one wins.
      return [
        {
          platform: "ICLOUD" as SocialPlatform,
          category: "ICLOUD",
          country: wizard.selectedCountries[0] ?? "USA",
          label: "USA iCloud",
        },
      ];
    }

    if (group.value === "INSTAGRAM" && group.instagramSubTypes) {
      return wizard.selectedSubTypes.map((st) => {
        const cfg = group.instagramSubTypes?.find((x) => x.value === st);
        return {
          platform: "INSTAGRAM" as SocialPlatform,
          category: "INSTAGRAM_FOLLOWERS",
          instagramSubType: st as InstagramSubType,
          followers: cfg?.followers,
          label: cfg?.label ?? st,
        };
      });
    }

    if (group.value === "VPN" && group.vpnTypes) {
      return wizard.selectedSubTypes.map((st) => {
        const cfg = group.vpnTypes?.find((x) => x.value === st);
        return {
          platform: "VPN" as SocialPlatform,
          category: "VPN",
          vpnType: st as VpnType,
          label: cfg?.label ?? st,
        };
      });
    }

    if (group.value === "TUTORIAL" && group.tutorialTypes) {
      return wizard.selectedSubTypes.map((st) => {
        const cfg = group.tutorialTypes?.find((x) => x.value === st);
        const platformMap: Record<TutorialType, SocialPlatform> = {
          FACEBOOK_ADS: "FACEBOOK",
          INSTAGRAM_ADS: "INSTAGRAM",
          TIKTOK_ADS: "TIKTOK",
          TWITTER_ADS: "X",
        };
        return {
          platform: platformMap[st as TutorialType],
          category: "TUTORIAL",
          tutorialType: st as TutorialType,
          label: cfg?.label ?? st,
        };
      });
    }

    if (group.value === "WEBSITE" && group.websiteTypes) {
      return wizard.selectedSubTypes.map((st) => {
        const cfg = group.websiteTypes?.find((x) => x.value === st);
        return {
          platform: "VPN" as SocialPlatform,
          category: "WEBSITE_CREATION",
          websiteType: st as WebsiteType,
          label: cfg?.label ?? st,
        };
      });
    }

    if (group.value === "WORKING_TOOLS" && group.workingToolTypes) {
      return wizard.selectedSubTypes.map((st) => {
        const cfg = group.workingToolTypes?.find((x) => x.value === st);
        return {
          platform: "TOOL" as SocialPlatform,
          category: "ALL_WORKING_TOOLS",
          workingToolType: st as WorkingToolType,
          label: cfg?.label ?? st,
        };
      });
    }

    if (needsPlatformChoice) {
      return wizard.selectedPlatforms.map((p) => ({
        platform: p,
        category: group.category as string,
        label: p === "TEXTPLUS" ? "TextPlus" : p === "NEXTPLUS" ? "NextPlus" : p,
      }));
    }

    const fallbackFollowers =
      group.hasFollowers && wizard.followers !== undefined ? wizard.followers : undefined;
    return [
      {
        platform: group.platforms[0],
        category: group.category as string,
        followers: fallbackFollowers,
        label: group.label,
      },
    ];
  }, [group, needsPlatformChoice, wizard]);

  const needsSubTypeChoice = !!(group?.instagramSubTypes || group?.vpnTypes || group?.tutorialTypes || group?.websiteTypes || group?.workingToolTypes);

  const showFollowers =
    group?.value === "TWITTER" ||
    (group?.value === "INSTAGRAM" &&
      wizard.selectedSubTypes.some((st) => {
        const cfg = group?.instagramSubTypes?.find((x) => x.value === st);
        return cfg?.followers !== undefined && cfg.followers > 0;
      })) ||
    (group?.value === "FACEBOOK" && wizard.selectedPageTypes.includes("PAGE_WITH_FOLLOWERS")) ||
    (group?.value === "TIKTOK" && wizard.includeFollowerTier);

  const step2Complete = submissions.length > 0;

  function reset() {
    setWizard(initialWizardState);
    setStep(1);
  }

  function handleClose() {
    onClose();
    reset();
  }

  function selectGroup(value: WizardGroup) {
    setWizard({ ...initialWizardState, group: value });
    setStep(2);
  }

  function changePlatform() {
    setWizard(initialWizardState);
    setStep(1);
  }

  function togglePageType(pt: SocialLogPageType) {
    setWizard((s) => ({
      ...s,
      selectedPageTypes: s.selectedPageTypes.includes(pt)
        ? s.selectedPageTypes.filter((v) => v !== pt)
        : [...s.selectedPageTypes, pt],
    }));
  }

  function togglePlatform(p: SocialPlatform) {
    setWizard((s) => ({
      ...s,
      selectedPlatforms: s.selectedPlatforms.includes(p)
        ? s.selectedPlatforms.filter((v) => v !== p)
        : [...s.selectedPlatforms, p],
    }));
  }

  function toggleSubType(st: string) {
    setWizard((s) => ({
      ...s,
      selectedSubTypes: s.selectedSubTypes.includes(st)
        ? s.selectedSubTypes.filter((v) => v !== st)
        : [...s.selectedSubTypes, st],
    }));
  }

  function toggleCountry(c: string) {
    setWizard((s) => ({
      ...s,
      selectedCountries: s.selectedCountries.includes(c)
        ? s.selectedCountries.filter((v) => v !== c)
        : [...s.selectedCountries, c],
    }));
  }

  async function handleSubmit() {
    if (submissions.length === 0) return;
    setSubmitting(true);
    try {
      for (const sub of submissions) {
        const payload = {
          platform: sub.platform,
          category: sub.category as any,
          pageType: sub.pageType,
          country: sub.country,
          followers: sub.followers,
          instagramSubType: sub.instagramSubType,
          vpnType: sub.vpnType,
          tutorialType: sub.tutorialType,
          websiteType: sub.websiteType,
          workingToolType: sub.workingToolType,
          toolLink: isWorkingTool ? wizard.details.toolLink : undefined,
          age: isWorkingTool ? 0 : (wizard.age ?? 0),
          username: wizard.details.username,
          price: wizard.details.price,
          description: wizard.details.description,
          emailAttached: wizard.details.emailAttached,
          phoneAttached: wizard.details.phoneAttached,
          twoFactor: wizard.details.twoFactor,
          ogEmail: wizard.details.ogEmail,
          verified: wizard.details.verified,
          loginUsername: wizard.details.loginUsername,
          loginEmail: wizard.details.loginEmail,
          emailPassword: wizard.details.emailPassword,
          accountPassword: wizard.details.accountPassword,
          twoFactorSecret: wizard.details.twoFactorSecret,
          recoveryEmail: wizard.details.recoveryEmail,
          backupCodes: wizard.details.backupCodes
            ? wizard.details.backupCodes.split(",").map((c: string) => c.trim()).filter(Boolean)
            : undefined,
          cookies: wizard.details.cookies
            ? (() => {
                try {
                  return JSON.parse(wizard.details.cookies);
                } catch {
                  return undefined;
                }
              })()
            : undefined,
          notes: wizard.details.notes,
          dateOfBirth: wizard.details.dateOfBirth || undefined,
          smsNumber: wizard.details.smsNumber || undefined,
          smsLink: wizard.details.smsLink || undefined,
        } as CreateSocialLogDto;

        await createSocialLog(payload);
      }
      toast.success(
        submissions.length > 1 ? `Added ${submissions.length} listings to stock.` : "Added to stock.",
      );
      handleClose();
      onCreated();
    } catch (err: any) {
      toast.error(err?.response?.data?.message ?? err?.message ?? "Failed to submit.");
    } finally {
      setSubmitting(false);
    }
  }
  
  function setDetail(key: string, value: any) {
    setWizard((s) => ({ ...s, details: { ...s.details, [key]: value } }));
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6 backdrop-blur-sm">
      <div className="max-h-[95vh] w-full max-w-3xl overflow-y-auto rounded-3xl border border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-[0_25px_80px_rgba(0,0,0,0.65)]">
        <div className="flex items-center justify-between border-b border-gray-200 dark:border-zinc-800 px-8 py-6">
          <div>
            <div className="flex items-center gap-2 text-2xl font-bold text-gray-900 dark:text-white">
              {step > 1 && group && (
                <button
                  onClick={changePlatform}
                  title="Change platform"
                  className="rounded-lg p-1 text-gray-400 dark:text-zinc-500 transition hover:bg-gray-100 dark:hover:bg-zinc-800 hover:text-gray-900 dark:hover:text-white"
                >
                  <ChevronLeft size={20} />
                </button>
              )}
              Add Social Log
              {group && <span className="text-base font-medium text-gray-400 dark:text-zinc-500">— {group.label}</span>}
            </div>
            <p className="mt-2 text-sm text-gray-500 dark:text-zinc-400">
              Step {step} of 4 · {STEP_LABELS[step - 1]}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 text-xl text-gray-500 dark:text-zinc-400 transition-all hover:border-red-500 hover:bg-red-500 hover:text-gray-900 dark:hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-6 bg-white dark:bg-zinc-900 p-8">
          <div className="flex gap-2">
            {STEP_LABELS.map((label, i) => (
              <div key={label} className="flex-1">
                <div className={`h-1.5 rounded-full ${i < step ? "bg-orange-600" : "bg-gray-100 dark:bg-zinc-800"}`} />
                <p className={`mt-1.5 text-center text-xs ${i < step ? "text-orange-400" : "text-zinc-600"}`}>
                  {label}
                </p>
              </div>
            ))}
          </div>

          {step === 1 && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {WIZARD_GROUPS.map((g) => (
                <button
                  key={g.value}
                  onClick={() => selectGroup(g.value)}
                  className="rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-6 text-center font-medium text-gray-900 dark:text-white transition hover:border-orange-500 hover:bg-zinc-750"
                >
                  {g.label}
                </button>
              ))}
            </div>
          )}

          {step === 2 && group && (
            <div className="space-y-5">
              {group.value === "FACEBOOK" && group.pageTypes && (
                <div>
                  <p className="mb-2 text-sm font-medium text-gray-700 dark:text-zinc-300">Page Types — select any that apply</p>
                  <div className="grid grid-cols-2 gap-3">
                    {group.pageTypes.map((pt) => {
                      const checked = wizard.selectedPageTypes.includes(pt.value);
                      return (
                        <button
                          key={pt.value}
                          onClick={() => togglePageType(pt.value)}
                          className={`flex items-center gap-2 rounded-xl border px-4 py-4 text-left text-sm font-medium transition ${
                            checked
                              ? "border-orange-500 bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-white"
                              : "border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-gray-700 dark:text-zinc-300 hover:border-zinc-500"
                          }`}
                        >
                          <span
                            className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                              checked ? "border-orange-500 bg-orange-500" : "border-zinc-600"
                            }`}
                          >
                            {checked && <span className="h-2 w-2 rounded-sm bg-white" />}
                          </span>
                          {pt.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {group.value === "TIKTOK" && (
                <>
                  <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-zinc-300">
                    <input
                      type="checkbox"
                      checked={wizard.includeFollowerTier}
                      onChange={(e) => setWizard((s) => ({ ...s, includeFollowerTier: e.target.checked }))}
                    />
                    Include a Follower-tier listing
                  </label>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">
                      Countries — adds a TikTok-by-Country listing for each selected country
                    </label>
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                      {group.countries?.map((c) => {
                        const checked = wizard.selectedCountries.includes(c.value);
                        return (
                          <button
                            key={c.value}
                            onClick={() => toggleCountry(c.value)}
                            className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                              checked
                                ? "border-orange-500 bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-white"
                                : "border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-gray-700 dark:text-zinc-300 hover:border-zinc-500"
                            }`}
                          >
                            {c.label}
                            <span
                              className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                                checked ? "border-orange-500 bg-orange-500" : "border-zinc-600"
                              }`}
                            >
                              {checked && <span className="h-2 w-2 rounded-sm bg-white" />}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}

              {needsSubTypeChoice && (group.instagramSubTypes || group.vpnTypes || group.tutorialTypes || group.websiteTypes || group.workingToolTypes) && (
                <div>
                  <p className="mb-2 text-sm font-medium text-gray-700 dark:text-zinc-300">
                    {isWorkingTool ? "Tool Boxes — select any that apply" : "Select any that apply"}
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {(group.instagramSubTypes || group.vpnTypes || group.tutorialTypes || group.websiteTypes || group.workingToolTypes || []).map((st: any) => {
                      const checked = wizard.selectedSubTypes.includes(st.value);
                      return (
                        <button
                          key={st.value}
                          onClick={() => toggleSubType(st.value)}
                          className={`flex items-center justify-between rounded-xl border px-4 py-4 text-left text-sm font-medium transition ${
                            checked
                              ? "border-orange-500 bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-white"
                              : "border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-gray-700 dark:text-zinc-300 hover:border-zinc-500"
                          }`}
                        >
                          {st.label}
                          <span
                            className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                              checked ? "border-orange-500 bg-orange-500" : "border-zinc-600"
                            }`}
                          >
                            {checked && <span className="h-2 w-2 rounded-sm bg-white" />}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {needsPlatformChoice && (
                <div>
                  <p className="mb-2 text-sm font-medium text-gray-700 dark:text-zinc-300">Select any that apply</p>
                  <div className="grid grid-cols-2 gap-3">
                    {group.platforms.map((p) => {
                      const checked = wizard.selectedPlatforms.includes(p);
                      return (
                        <button
                          key={p}
                          onClick={() => togglePlatform(p)}
                          className={`flex items-center gap-2 rounded-xl border px-4 py-4 text-left text-sm font-medium transition ${
                            checked
                              ? "border-orange-500 bg-gray-100 dark:bg-zinc-800 text-gray-900 dark:text-white"
                              : "border-gray-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-gray-700 dark:text-zinc-300 hover:border-zinc-500"
                          }`}
                        >
                          <span
                            className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                              checked ? "border-orange-500 bg-orange-500" : "border-zinc-600"
                            }`}
                          >
                            {checked && <span className="h-2 w-2 rounded-sm bg-white" />}
                          </span>
                          {p}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {submissions.length > 0 && (
                <div className="rounded-xl border border-orange-500/30 bg-orange-500/10 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-orange-300">
                    Will create {submissions.length} listing{submissions.length > 1 ? "s" : ""}
                  </p>
                  <ul className="mt-2 space-y-1 text-sm text-orange-100">
                    {submissions.map((s, i) => (
                      <li key={i}>• {s.label}</li>
                    ))}
                  </ul>
                </div>
              )}

              {submissions.length === 0 && (
                <p className="text-xs text-gray-400 dark:text-zinc-500">Select at least one option above to continue.</p>
              )}

              <div className="flex justify-between pt-2">
                <button onClick={() => setStep(1)} className="text-sm text-gray-500 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white">
                  Back
                </button>
                <button
                  disabled={!step2Complete}
                  onClick={() => setStep(isWorkingTool ? 4 : 3)}
                  className="rounded-xl bg-orange-600 px-5 py-2.5 text-sm font-medium text-white disabled:opacity-40"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 3 && group && !isWorkingTool && (
            <div className="space-y-4">
              {showFollowers && (
                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">
                    {group.value === "TWITTER" || group.value === "TIKTOK" ? "Follower Tier" : "Follower Count"}
                  </label>
                  {group.value === "TWITTER" ? (
                    <div className="flex flex-wrap gap-2">
                      {TWITTER_FOLLOWER_TIERS.map((tier) => (
                        <button
                          key={tier.value}
                          type="button"
                          onClick={() => setWizard((s) => ({ ...s, followers: tier.value }))}
                          className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition ${
                            wizard.followers === tier.value
                              ? "border-orange-500 bg-orange-500/10 text-orange-600 dark:text-orange-400"
                              : "border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 hover:border-zinc-500"
                          }`}
                        >
                          {tier.label}
                        </button>
                      ))}
                    </div>
                  ) : group.value === "TIKTOK" && wizard.includeFollowerTier ? (
                    <div className="flex flex-wrap gap-2">
                      {TIKTOK_FOLLOWER_TIERS.map((tier) => (
                        <button
                          key={tier.value}
                          type="button"
                          onClick={() => setWizard((s) => ({ ...s, followers: tier.value }))}
                          className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition ${
                            wizard.followers === tier.value
                              ? "border-orange-500 bg-orange-500/10 text-orange-600 dark:text-orange-400"
                              : "border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-zinc-400 hover:border-zinc-500"
                          }`}
                        >
                          {tier.label}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <input
                      type="number"
                      value={wizard.followers ?? ""}
                      onChange={(e) => setWizard((s) => ({ ...s, followers: Number(e.target.value) }))}
                      className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                    />
                  )}
                </div>
              )}
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Account Age (months)</label>
                <input
                  type="number"
                  value={wizard.age ?? ""}
                  onChange={(e) => setWizard((s) => ({ ...s, age: Number(e.target.value) }))}
                  className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                />
              </div>
              <div className="flex justify-between pt-2">
                <button onClick={() => setStep(2)} className="text-sm text-gray-500 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white">
                  Back
                </button>
                <button onClick={() => setStep(4)} className="rounded-xl bg-orange-600 px-5 py-2.5 text-sm font-medium text-white">
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 4 && group && (
            <div className="space-y-4">
              <div className="rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-100/50 dark:bg-zinc-800/50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-zinc-400">
                  About to create {submissions.length} listing{submissions.length > 1 ? "s" : ""}
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-700 dark:text-zinc-300">
                  {submissions.map((s, i) => (
                    <li key={i}>• {s.label}</li>
                  ))}
                </ul>
                {submissions.length > 1 && (
                  <p className="mt-2 text-xs text-gray-400 dark:text-zinc-500">
                    The fields below apply to all of them — username/price/credentials are shared.
                  </p>
                )}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">
                  {isWorkingTool ? "Label / Tool Name" : "Username / Label"}
                </label>
                <input
                  value={wizard.details.username ?? ""}
                  onChange={(e) => setDetail("username", e.target.value)}
                  className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                />
              </div>

              {isWorkingTool && (
                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Tool Link (URL)</label>
                  <input
                    value={wizard.details.toolLink ?? ""}
                    onChange={(e) => setDetail("toolLink", e.target.value)}
                    placeholder="https://..."
                    className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                  />
                </div>
              )}

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Price (₦)</label>
                <input
                  type="number"
                  value={wizard.details.price ?? ""}
                  onChange={(e) => setDetail("price", Number(e.target.value))}
                  className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                />
              </div>

              {!isWorkingTool && (
                <div className="grid grid-cols-2 gap-3">
                  {["emailAttached", "phoneAttached", "twoFactor", "ogEmail", "verified"].map((flag) => (
                    <label key={flag} className="flex items-center gap-2 text-sm text-gray-700 dark:text-zinc-300">
                      <input
                        type="checkbox"
                        checked={!!wizard.details[flag]}
                        onChange={(e) => setDetail(flag, e.target.checked)}
                      />
                      {flag}
                    </label>
                  ))}
                </div>
              )}

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Description</label>
                <textarea
                  value={wizard.details.description ?? ""}
                  onChange={(e) => setDetail("description", e.target.value)}
                  rows={2}
                  className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                />
              </div>

              {!isWorkingTool && (
                <>
                  <p className="pt-2 text-xs font-semibold uppercase tracking-wide text-gray-400 dark:text-zinc-500">
                    Private details — only revealed to the buyer after purchase
                  </p>

                  {group.value === "ICLOUD" && (
                    <div className="grid grid-cols-2 gap-3 rounded-xl border border-sky-500/20 bg-sky-500/5 p-4">
                      <div>
                        <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Date of Birth</label>
                        <input
                          value={wizard.details.dateOfBirth ?? ""}
                          onChange={(e) => setDetail("dateOfBirth", e.target.value)}
                          placeholder="2000-01-01"
                          className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                        />
                      </div>

                      <div>
                        <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Number (receives SMS)</label>
                        <input
                          value={wizard.details.smsNumber ?? ""}
                          onChange={(e) => setDetail("smsNumber", e.target.value)}
                          placeholder="+16204707136"
                          className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">SMS Site Link</label>
                        <input
                          value={wizard.details.smsLink ?? ""}
                          onChange={(e) => setDetail("smsLink", e.target.value)}
                          placeholder="https://api1997.com/smsrecord?token=..."
                          className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 font-mono text-xs text-gray-900 dark:text-white"
                        />
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Username</label>
                      <input
                        value={wizard.details.loginUsername ?? ""}
                        onChange={(e) => setDetail("loginUsername", e.target.value)}
                        placeholder="Login username"
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Login Email</label>
                      <input
                        value={wizard.details.loginEmail ?? ""}
                        onChange={(e) => setDetail("loginEmail", e.target.value)}
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Email Password</label>
                      <input
                        type="password"
                        value={wizard.details.emailPassword ?? ""}
                        onChange={(e) => setDetail("emailPassword", e.target.value)}
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Account Password</label>
                      <input
                        type="password"
                        value={wizard.details.accountPassword ?? ""}
                        onChange={(e) => setDetail("accountPassword", e.target.value)}
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">2FA Secret</label>
                      <input
                        value={wizard.details.twoFactorSecret ?? ""}
                        onChange={(e) => setDetail("twoFactorSecret", e.target.value)}
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Recovery Email</label>
                      <input
                        value={wizard.details.recoveryEmail ?? ""}
                        onChange={(e) => setDetail("recoveryEmail", e.target.value)}
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Backup Codes (comma separated)</label>
                      <input
                        value={wizard.details.backupCodes ?? ""}
                        onChange={(e) => setDetail("backupCodes", e.target.value)}
                        placeholder="code1, code2, code3"
                        className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                      />
                    </div>


                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Cookies (optional, valid JSON)</label>
                    <textarea
                      value={wizard.details.cookies ?? ""}
                      onChange={(e) => setDetail("cookies", e.target.value)}
                      rows={2}
                      placeholder='{"sessionid": "..."}'
                      className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white font-mono text-xs"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-zinc-300">Notes</label>
                    <textarea
                      value={wizard.details.notes ?? ""}
                      onChange={(e) => setDetail("notes", e.target.value)}
                      rows={2}
                      className="w-full rounded-xl border border-gray-300 dark:border-zinc-700 bg-gray-100 dark:bg-zinc-800 px-4 py-3 text-gray-900 dark:text-white"
                    />
                  </div>
                </>
              )}

              <div className="flex justify-between pt-2">
                <button onClick={() => setStep(isWorkingTool ? 2 : 3)} className="text-sm text-gray-500 dark:text-zinc-400 hover:text-gray-900 dark:hover:text-white">
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="rounded-xl bg-orange-600 px-5 py-2.5 text-sm font-medium text-white disabled:opacity-60"
                >
                  {submitting
                    ? "Submitting…"
                    : submissions.length > 1
                      ? `Add ${submissions.length} to Stock`
                      : "Add to Stock"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}