"use client";

import { useEffect, useState } from "react";
import { User, Lock, Bell, Shield, Save, Loader2, Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import api from "@/lib/axios";

/* ===============================
   Types
=============================== */

interface UserProfile {
  name: string;
  email: string;
  phone: string;
}

interface NotificationPrefs {
  email: boolean;
  sms: boolean;
  orderUpdates: boolean;
  promotions: boolean;
}

/* ===============================
   Service calls
   Backend endpoints (all confirmed):
   - GET    /auth/me            → { name, email, ... }
   - PATCH  /auth/me            → { name, email? }   (UpdateProfileDto)
   - PATCH  /auth/me/password   → { currentPassword, newPassword }
   Notification preferences are stored locally (localStorage) since
   there is no backend endpoint for them yet.
=============================== */

// `api` (shared @/lib/axios) already unwraps the response in its
// interceptor — every call below resolves DIRECTLY to the backend
// payload. Don't destructure `.data` off the result again.

async function fetchMe(): Promise<UserProfile> {
  const data: any = await api.get("/auth/me");
  const user = data?.data ?? data;
  return {
    name: user.name ?? user.fullName ?? "",
    email: user.email ?? "",
    phone: user.phone ?? "",
  };
}

async function updateProfile(payload: { name: string; email?: string }) {
  const data: any = await api.patch("/auth/me", {
    name: payload.name,
    email: payload.email,
  });
  return data?.data ?? data;
}

async function updatePassword(payload: { current: string; next: string }) {
  const data: any = await api.patch("/auth/me/password", {
    currentPassword: payload.current,
    newPassword: payload.next,
  });
  return data?.data ?? data;
}

/* ===============================
   Page
=============================== */

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<"profile" | "security" | "notifications" | "appearance">("profile");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const [profile, setProfile] = useState<UserProfile>({
    name: "",
    email: "",
    phone: "",
  });

  const [password, setPassword] = useState({
    current: "",
    next: "",
    confirm: "",
  });

  const [notifications, setNotifications] = useState<NotificationPrefs>({
    email: true,
    sms: false,
    orderUpdates: true,
    promotions: false,
  });

  /* ── Load current user + saved notification prefs on mount ── */
  useEffect(() => {
    let cancelled = false;

    // Restore locally-saved notification preferences
    try {
      const saved = localStorage.getItem("notification_prefs");
      if (saved) {
        const parsed = JSON.parse(saved) as NotificationPrefs;
        if (!cancelled) setNotifications(parsed);
      }
    } catch {
      // ignore parse errors
    }

    (async () => {
      try {
        setLoading(true);
        const data = await fetchMe();
        if (!cancelled) setProfile(data);
      } catch (err: any) {
        if (err?.response?.status === 401) return; // handled by interceptor
        toast.error(err?.response?.data?.message ?? "Failed to load your profile.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  /* ── Save handlers, one per tab ── */

  const handleSaveProfile = async () => {
    if (!profile.name.trim()) {
      toast.error("Full name is required.");
      return;
    }
    if (!profile.email.trim()) {
      toast.error("Email is required.");
      return;
    }

    try {
      setSaving(true);
      await updateProfile({ name: profile.name, email: profile.email });
      toast.success("Profile updated.");
    } catch (err: any) {
      if (err?.response?.status === 401) return;
      toast.error(err?.response?.data?.message ?? "Failed to update profile.");
    } finally {
      setSaving(false);
    }
  };

  const handleSavePassword = async () => {
    if (!password.current) {
      toast.error("Enter your current password.");
      return;
    }
    if (password.next.length < 8) {
      toast.error("New password must be at least 8 characters.");
      return;
    }
    if (password.next !== password.confirm) {
      toast.error("New password and confirmation don't match.");
      return;
    }

    try {
      setSaving(true);
      await updatePassword({ current: password.current, next: password.next });
      toast.success("Password changed.");
      setPassword({ current: "", next: "", confirm: "" });
    } catch (err: any) {
      if (err?.response?.status === 401) return;
      toast.error(err?.response?.data?.message ?? "Failed to change password.");
    } finally {
      setSaving(false);
    }
  };

  const handleSaveNotifications = async () => {
    try {
      setSaving(true);
      // No backend endpoint yet — save locally so preferences persist
      localStorage.setItem("notification_prefs", JSON.stringify(notifications));
      toast.success("Notification preferences saved.");
    } catch (err: any) {
      toast.error("Failed to save preferences.");
    } finally {
      setSaving(false);
    }
  };

  const handleSave = () => {
    if (activeTab === "profile") return handleSaveProfile();
    if (activeTab === "security") return handleSavePassword();
    return handleSaveNotifications();
  };

  const tabs = [
    { id: "profile" as const, label: "Profile", icon: User },
    { id: "security" as const, label: "Security", icon: Lock },
    { id: "notifications" as const, label: "Notifications", icon: Bell },
    { id: "appearance" as const, label: "Appearance", icon: Moon },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-white dark:bg-[#0f172a] flex items-center justify-center">
        <Loader2 className="animate-spin text-orange-500" size={28} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-[#0f172a] text-gray-900 dark:text-white p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-gray-500 dark:text-zinc-400 text-sm mt-1">
          Manage your account, security, and notification preferences.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar tabs */}
        <div className="md:w-56 shrink-0">
          <div className="bg-gray-50 dark:bg-[#0B1220] border border-gray-200 dark:border-zinc-800 rounded-xl p-2 flex md:flex-col gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-orange-500 text-white"
                      : "text-gray-500 dark:text-zinc-400 hover:bg-gray-100/50 dark:hover:bg-zinc-800/50 hover:text-gray-900 dark:hover:text-white"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 bg-gray-50 dark:bg-[#0B1220] border border-gray-200 dark:border-zinc-800 rounded-xl p-6">
          {activeTab === "profile" && (
            <div className="space-y-4 max-w-md">
              <h2 className="text-lg font-medium mb-4">Profile information</h2>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">Full name</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">Email address</label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">Phone number</label>
                <input
                  type="tel"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                  placeholder="+234..."
                />
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div className="space-y-4 max-w-md">
              <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
                <Shield size={18} className="text-orange-500" />
                Change password
              </h2>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">Current password</label>
                <input
                  type="password"
                  value={password.current}
                  onChange={(e) => setPassword({ ...password, current: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">New password</label>
                <input
                  type="password"
                  value={password.next}
                  onChange={(e) => setPassword({ ...password, next: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="text-sm text-gray-500 dark:text-zinc-400 block mb-1.5">Confirm new password</label>
                <input
                  type="password"
                  value={password.confirm}
                  onChange={(e) => setPassword({ ...password, confirm: e.target.value })}
                  className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-3 py-2 text-sm text-gray-900 dark:text-white outline-none focus:border-orange-500"
                />
              </div>
            </div>
          )}

          {activeTab === "notifications" && (
            <div className="space-y-4 max-w-md">
              <h2 className="text-lg font-medium mb-4">Notification preferences</h2>
              {[
                { key: "email" as const, label: "Email notifications" },
                { key: "sms" as const, label: "SMS notifications" },
                { key: "orderUpdates" as const, label: "Order status updates" },
                { key: "promotions" as const, label: "Promotions & offers" },
              ].map((item) => (
                <div
                  key={item.key}
                  className="flex items-center justify-between bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-4 py-3"
                >
                  <span className="text-sm text-gray-800 dark:text-zinc-200">{item.label}</span>
                  <button
                    onClick={() =>
                      setNotifications({ ...notifications, [item.key]: !notifications[item.key] })
                    }
                    className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
                      notifications[item.key] ? "bg-orange-500" : "bg-gray-200 dark:bg-zinc-700"
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                        notifications[item.key] ? "translate-x-5" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === "appearance" && (
            <div className="space-y-4 max-w-md">
              <h2 className="text-lg font-medium mb-4">Appearance</h2>

              <div className="flex items-center justify-between bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-zinc-800 rounded-lg px-4 py-3">
                <div className="flex items-center gap-3">
                  {mounted && resolvedTheme === "dark" ? (
                    <Moon size={18} className="text-orange-500" />
                  ) : (
                    <Sun size={18} className="text-orange-500" />
                  )}
                  <div>
                    <p className="text-sm text-gray-800 dark:text-zinc-200">Dark mode</p>
                    <p className="text-xs text-gray-500 dark:text-zinc-400">
                      {mounted && resolvedTheme === "dark" ? "Currently on" : "Currently off"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                  aria-label="Toggle dark mode"
                  className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
                    mounted && resolvedTheme === "dark" ? "bg-orange-500" : "bg-gray-200 dark:bg-zinc-700"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition-transform ${
                      mounted && resolvedTheme === "dark" ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            </div>
          )}

          {activeTab !== "appearance" && (
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-zinc-800">
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex items-center gap-2 bg-orange-500 hover:bg-orange-600 disabled:opacity-60 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
              >
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                {saving ? "Saving..." : "Save changes"}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}